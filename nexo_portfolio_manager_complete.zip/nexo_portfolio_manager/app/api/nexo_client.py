import requests
import time
import hashlib
import hmac
import json
from typing import Dict, List, Optional
from datetime import datetime

from config.settings import settings

class NexoProClient:
    def __init__(self, api_key: str = None, api_secret: str = None):
        self.api_key = api_key or settings.NEXO_PUBLIC_KEY
        self.api_secret = api_secret or settings.NEXO_SECRET_KEY
        self.base_url = "https://api.nexo.io/pro/v1"

        if not self.api_key or not self.api_secret:
            raise ValueError("Nexo Pro API credentials not provided")

    def _generate_signature(self, timestamp: str, method: str, path: str, body: str = "") -> str:
        """Generate HMAC signature for Nexo Pro API"""
        message = timestamp + method.upper() + path + body
        signature = hmac.new(
            self.api_secret.encode('utf-8'),
            message.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
        return signature

    def _make_request(self, method: str, endpoint: str, params: Dict = None, data: Dict = None) -> Dict:
        """Make authenticated request to Nexo Pro API"""
        timestamp = str(int(time.time() * 1000))
        path = f"/pro/v1{endpoint}"

        if method.upper() == "GET" and params:
            query_string = "&".join([f"{k}={v}" for k, v in params.items()])
            path += f"?{query_string}"
            body = ""
        else:
            body = json.dumps(data) if data else ""

        signature = self._generate_signature(timestamp, method, path, body)

        headers = {
            "X-API-KEY": self.api_key,
            "X-TIMESTAMP": timestamp,
            "X-SIGNATURE": signature,
            "Content-Type": "application/json"
        }

        url = f"{self.base_url}{endpoint}"

        try:
            if method.upper() == "GET":
                response = requests.get(url, headers=headers, params=params)
            elif method.upper() == "POST":
                response = requests.post(url, headers=headers, json=data)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")

            response.raise_for_status()
            return response.json()

        except requests.exceptions.RequestException as e:
            print(f"API request failed: {e}")
            if hasattr(e, 'response') and e.response is not None:
                print(f"Response: {e.response.text}")
            raise

    def get_account_summary(self) -> Dict:
        """Get account balances and summary"""
        return self._make_request("GET", "/accountSummary")

    def get_pairs(self) -> List[Dict]:
        """Get available trading pairs"""
        return self._make_request("GET", "/pairs")

    def get_quote(self, pair: str, amount: float, side: str) -> Dict:
        """Get price quote for a trade"""
        params = {
            "pair": pair,
            "amount": amount,
            "side": side
        }
        return self._make_request("GET", "/quote", params=params)

    def place_order(self, pair: str, side: str, quantity: float, order_type: str = "market") -> Dict:
        """Place a trading order"""
        data = {
            "pair": pair,
            "side": side,
            "type": order_type,
            "quantity": quantity
        }
        return self._make_request("POST", "/orders", data=data)

    def cancel_order(self, order_id: str) -> Dict:
        """Cancel an existing order"""
        data = {"orderId": order_id}
        return self._make_request("POST", "/orders/cancel", data=data)

    def get_order_history(self, pairs: List[str] = None, limit: int = 100) -> List[Dict]:
        """Get order history"""
        params = {"pageSize": limit}
        if pairs:
            params["pairs"] = ",".join(pairs)

        return self._make_request("GET", "/orders", params=params)

    def get_trades(self, pairs: List[str] = None, limit: int = 100) -> List[Dict]:
        """Get trade history"""
        params = {"pageSize": limit}
        if pairs:
            params["pairs"] = ",".join(pairs)

        return self._make_request("GET", "/trades", params=params)

class MockNexoClient:
    """Mock client for testing and development"""

    def __init__(self):
        self.mock_balances = {
            "BTC": {"balance": 0.1, "price": 45000},
            "ETH": {"balance": 2.5, "price": 3000},
            "ADA": {"balance": 1000, "price": 0.5},
            "USDT": {"balance": 5000, "price": 1.0}
        }

    def get_account_summary(self) -> Dict:
        """Mock account summary"""
        balances = []
        total_value = 0

        for token, data in self.mock_balances.items():
            value = data["balance"] * data["price"]
            total_value += value
            balances.append({
                "asset": token,
                "balance": data["balance"],
                "priceUsd": data["price"],
                "valueUsd": value
            })

        return {
            "balances": balances,
            "totalValueUsd": total_value
        }

    def get_pairs(self) -> List[Dict]:
        """Mock trading pairs"""
        return [
            {"pair": "BTC/USDT", "minAmount": 0.001, "maxAmount": 100},
            {"pair": "ETH/USDT", "minAmount": 0.01, "maxAmount": 1000},
            {"pair": "ADA/USDT", "minAmount": 1, "maxAmount": 100000}
        ]

    def get_quote(self, pair: str, amount: float, side: str) -> Dict:
        """Mock price quote"""
        # Simplified mock - in reality this would be more complex
        base_token = pair.split("/")[0]
        if base_token in self.mock_balances:
            price = self.mock_balances[base_token]["price"]
            return {
                "pair": pair,
                "side": side,
                "amount": amount,
                "price": price,
                "total": amount * price,
                "fee": amount * price * 0.002  # 0.2% fee
            }
        return {}

    def place_order(self, pair: str, side: str, quantity: float, order_type: str = "market") -> Dict:
        """Mock order placement"""
        return {
            "orderId": f"mock-{int(time.time())}",
            "pair": pair,
            "side": side,
            "quantity": quantity,
            "type": order_type,
            "status": "filled",
            "timestamp": datetime.now().isoformat()
        }

def get_nexo_client(use_mock: bool = False) -> NexoProClient:
    """Get Nexo client instance"""
    if use_mock or not settings.NEXO_PUBLIC_KEY:
        return MockNexoClient()
    else:
        return NexoProClient()